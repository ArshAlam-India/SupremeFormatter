/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { GoogleGenAI } from "@google/genai";
import { 
  Copy, 
  Loader2, 
  Sparkles, 
  Terminal, 
  Moon, 
  Sun, 
  ChevronRight, 
  Shield, 
  Zap,
  Command,
  ExternalLink
} from "lucide-react";
import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";

// Utility to convert text to Mathematical Bold Sans-Serif
const toBoldSans = (text: string): string => {
  const charMap: Record<string, string> = {
    'A': '𝗔', 'B': '𝗕', 'C': '𝗖', 'D': '𝗗', 'E': '𝗘', 'F': '𝗙', 'G': '𝗚', 'H': '𝗛', 'I': '𝗜', 'J': '𝗝', 'K': '𝗞', 'L': '𝗟', 'M': '𝗠', 'N': '𝗡', 'O': '𝗢', 'P': '𝗣', 'Q': '𝗤', 'R': '𝗥', 'S': '𝗦', 'T': '𝗧', 'U': '𝗨', 'V': '𝗩', 'W': '𝗪', 'X': '𝗫', 'Y': '𝗬', 'Z': '𝗭',
    'a': '𝗮', 'b': '𝗯', 'c': '𝗰', 'd': '𝗱', 'e': '𝗲', 'f': '𝗳', 'g': '𝗴', 'h': '𝗵', 'i': '𝗶', 'j': '𝗷', 'k': '𝗸', 'l': '𝗹', 'm': '𝗺', 'n': '𝗻', 'o': '𝗼', 'p': '𝗽', 'q': '𝗾', 'r': '𝗿', 's': '𝘀', 't': '𝘁', 'u': '𝘂', 'v': '𝘃', 'w': '𝘄', 'x': '𝘅', 'y': '𝘆', 'z': '𝘇',
    '0': '𝟬', '1': '𝟭', '2': '𝟮', '3': '𝟯', '4': '𝟰', '5': '𝟱', '6': '𝟲', '7': '𝟳', '8': '𝟴', '9': '𝟵'
  };
  return text.split('').map(char => charMap[char] || char).join('');
};

export default function App() {
  const [input, setInput] = useState("");
  const [output, setOutput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [copyStatus, setCopyStatus] = useState("Copy Result");
  const [theme, setTheme] = useState<"dark" | "light">("dark");
  const [activeTab, setActiveTab] = useState<"input" | "preview">("input");

  // Sync theme with document class
  useEffect(() => {
    if (theme === "dark") {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  }, [theme]);

  const formatMessage = async () => {
    if (!input.trim()) return;
    setIsLoading(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Transform the following raw text into a Supreme Dynasty Discord announcement.
        
### THE SUPREME STYLE GUIDE:
1. TONE: Professional, direct, and slightly aggressive. Use words like "Grind," "Law," "High Council," and "Elite."
2. STRUCTURE: 
   - Start with a Title/Header using the 🏆 or 🛡️ or 💰 emoji.
   - Use Blockquotes (>) for the core message.
   - Use Bullet points (•) for lists or steps.
3. SIGN-OFF: End with "𝗚𝗿𝗶𝗻𝗱 𝗮𝗻𝗱 𝗲𝗻𝗷𝗼𝘆."

### OUTPUT RESTRICTIONS:
- Keep it under 100 words.
- Do not add any conversational filler.
- I will handle the Bold-Sans conversion for headings, so just provide the plain text structure and I will apply the font.

RAW TEXT: "${input}"`,
      });

      let result = response.text || "";
      
      const lines = result.split('\n');
      const formattedLines = lines.map((line, index) => {
        if (index === 0 || line.match(/^[🏆🛡️💰📜]/)) {
          return toBoldSans(line);
        }
        if (line.includes("Grind and enjoy")) {
          return toBoldSans(line);
        }
        return line.replace(/\*\*([^*]+)\*\*/g, (_, p1) => toBoldSans(p1));
      });

      setOutput(formattedLines.join('\n'));
      setActiveTab("preview");
    } catch (error) {
      console.error("Formatting failed:", error);
      setOutput("⚠️ ERROR: THE HIGH COUNCIL HAS ENCOUNTERED A SYSTEM FAILURE.");
    } finally {
      setIsLoading(false);
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(output);
    setCopyStatus("Copied!");
    setTimeout(() => setCopyStatus("Copy Result"), 2000);
  };

  const toggleTheme = () => setTheme(prev => prev === "dark" ? "light" : "dark");

  return (
    <div className={`min-h-screen transition-colors duration-500 ${theme === 'dark' ? 'bg-[#050505] text-white' : 'bg-[#F5F5F5] text-black'} font-sans selection:bg-orange-500 selection:text-white overflow-x-hidden`}>
      {/* Background Decorative Elements */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden opacity-20">
        <div className={`absolute top-[-10%] left-[-10%] w-[40%] h-[40%] rounded-full blur-[120px] ${theme === 'dark' ? 'bg-orange-900/20' : 'bg-orange-200/40'}`} />
        <div className={`absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] rounded-full blur-[120px] ${theme === 'dark' ? 'bg-blue-900/10' : 'bg-blue-100/30'}`} />
      </div>

      {/* Navigation / Header */}
      <header className={`sticky top-0 z-50 backdrop-blur-md border-b ${theme === 'dark' ? 'border-white/5 bg-black/50' : 'border-black/5 bg-white/50'} p-4 md:p-6`}>
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex items-center gap-4"
          >
            <div className={`w-12 h-12 ${theme === 'dark' ? 'bg-orange-600' : 'bg-black'} rounded-sm flex items-center justify-center rotate-3 shadow-xl`}>
              <Terminal size={28} className={theme === 'dark' ? 'text-black' : 'text-white'} />
            </div>
            <div>
              <h1 className="text-2xl font-[900] tracking-tighter uppercase italic leading-none">Supreme Dynasty</h1>
              <div className="flex items-center gap-2 mt-1">
                <span className={`text-[9px] uppercase tracking-[0.3em] font-black px-1.5 py-0.5 rounded ${theme === 'dark' ? 'bg-white/10 text-white/60' : 'bg-black/10 text-black/60'}`}>
                  Formatter v2.0
                </span>
                <span className="w-1 h-1 rounded-full bg-orange-500 animate-pulse" />
                <span className={`text-[9px] uppercase tracking-widest font-bold ${theme === 'dark' ? 'text-white/30' : 'text-black/30'}`}>
                  Secure Link Established
                </span>
              </div>
            </div>
          </motion.div>

          <div className="flex items-center gap-3">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={toggleTheme}
              className={`p-3 rounded-full border transition-all ${theme === 'dark' ? 'border-white/10 hover:bg-white/5 text-white' : 'border-black/10 hover:bg-black/5 text-black'}`}
            >
              {theme === "dark" ? <Sun size={18} /> : <Moon size={18} />}
            </motion.button>
            <div className={`hidden md:flex flex-col items-end text-[10px] uppercase tracking-widest font-mono ${theme === 'dark' ? 'text-white/20' : 'text-black/20'}`}>
              <span>Access: High Council</span>
              <span>Node: {Math.random().toString(36).substring(7).toUpperCase()}</span>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto p-4 md:p-8 mt-4 md:mt-8 relative z-10">
        {/* Mobile Tab Switcher */}
        <div className="lg:hidden flex mb-6 bg-white/5 p-1 rounded-lg border border-white/10">
          <button 
            onClick={() => setActiveTab("input")}
            className={`flex-1 py-2 text-[10px] uppercase tracking-widest font-black rounded-md transition-all ${activeTab === "input" ? 'bg-orange-600 text-white shadow-lg' : 'text-white/40'}`}
          >
            Intelligence
          </button>
          <button 
            onClick={() => setActiveTab("preview")}
            className={`flex-1 py-2 text-[10px] uppercase tracking-widest font-black rounded-md transition-all ${activeTab === "preview" ? 'bg-orange-600 text-white shadow-lg' : 'text-white/40'}`}
          >
            Deployment
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          
          {/* Left Column: Input & Controls */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className={`lg:col-span-7 space-y-6 ${activeTab !== "input" && 'hidden lg:block'}`}
          >
            <div className={`p-1 rounded-2xl border transition-all ${theme === 'dark' ? 'bg-white/[0.03] border-white/10' : 'bg-black/[0.02] border-black/10 shadow-sm'}`}>
              <div className="p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${theme === 'dark' ? 'bg-orange-500/20 text-orange-500' : 'bg-orange-100 text-orange-600'}`}>
                      <Command size={16} />
                    </div>
                    <h2 className="text-xs uppercase tracking-[0.2em] font-black">Raw Intelligence Intake</h2>
                  </div>
                  <div className={`text-[10px] font-mono px-2 py-1 rounded ${theme === 'dark' ? 'bg-white/5 text-white/40' : 'bg-black/5 text-black/40'}`}>
                    BUFFER_READY
                  </div>
                </div>

                <div className="relative group">
                  <textarea
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    placeholder="Enter raw staff text or messy member updates..."
                    className={`w-full h-[450px] bg-transparent border-0 p-0 focus:ring-0 transition-all resize-none font-mono text-sm leading-relaxed placeholder:text-white/10 ${theme === 'dark' ? 'text-white/90' : 'text-black/90'}`}
                  />
                  
                  {/* Scanning Line Animation */}
                  {isLoading && (
                    <motion.div 
                      initial={{ top: 0 }}
                      animate={{ top: "100%" }}
                      transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                      className="absolute left-0 right-0 h-[2px] bg-orange-500/50 blur-[2px] z-20 pointer-events-none"
                    />
                  )}
                </div>

                <div className="flex items-center justify-between pt-4 border-t border-white/5">
                  <div className="flex gap-2">
                    <div className={`w-2 h-2 rounded-full ${input.length > 0 ? 'bg-green-500' : 'bg-white/10'}`} />
                    <div className={`w-2 h-2 rounded-full ${input.length > 50 ? 'bg-green-500' : 'bg-white/10'}`} />
                    <div className={`w-2 h-2 rounded-full ${input.length > 150 ? 'bg-green-500' : 'bg-white/10'}`} />
                  </div>
                  <span className={`text-[10px] font-mono ${theme === 'dark' ? 'text-white/20' : 'text-black/20'}`}>
                    {input.length} / 2000 CHARS
                  </span>
                </div>
              </div>
            </div>

            <motion.button
              whileHover={{ scale: 1.01, backgroundColor: theme === 'dark' ? '#ea580c' : '#000' }}
              whileTap={{ scale: 0.99 }}
              onClick={formatMessage}
              disabled={isLoading || !input.trim()}
              className={`w-full py-5 rounded-2xl font-black uppercase tracking-[0.3em] transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-3 shadow-2xl ${theme === 'dark' ? 'bg-white text-black' : 'bg-black text-white'}`}
            >
              {isLoading ? (
                <>
                  <Loader2 className="animate-spin" size={20} />
                  Processing...
                </>
              ) : (
                <>
                  <Zap size={20} fill="currentColor" />
                  Initialize Transformation
                </>
              )}
            </motion.button>
          </motion.div>

          {/* Right Column: Preview & Stats */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className={`lg:col-span-5 space-y-6 ${activeTab !== "preview" && 'hidden lg:block'}`}
          >
            {/* Stats Bento */}
            <div className="grid grid-cols-2 gap-4">
              <div className={`p-4 rounded-2xl border ${theme === 'dark' ? 'bg-white/[0.03] border-white/10' : 'bg-white border-black/5 shadow-sm'}`}>
                <p className={`text-[9px] uppercase tracking-widest font-bold mb-1 ${theme === 'dark' ? 'text-white/40' : 'text-black/40'}`}>Authority Level</p>
                <p className="text-xl font-black italic tracking-tighter text-orange-500">SUPREME</p>
              </div>
              <div className={`p-4 rounded-2xl border ${theme === 'dark' ? 'bg-white/[0.03] border-white/10' : 'bg-white border-black/5 shadow-sm'}`}>
                <p className={`text-[9px] uppercase tracking-widest font-bold mb-1 ${theme === 'dark' ? 'text-white/40' : 'text-black/40'}`}>Encryption</p>
                <p className={`text-xl font-black italic tracking-tighter ${theme === 'dark' ? 'text-white' : 'text-black'}`}>ACTIVE</p>
              </div>
            </div>

            {/* Main Output Box */}
            <div className={`relative rounded-2xl border overflow-hidden transition-all ${theme === 'dark' ? 'bg-[#0a0a0a] border-white/10' : 'bg-white border-black/10 shadow-xl'}`}>
              <div className={`p-4 border-b flex items-center justify-between ${theme === 'dark' ? 'border-white/5 bg-white/[0.02]' : 'border-black/5 bg-black/[0.02]'}`}>
                <div className="flex items-center gap-2">
                  <div className="flex gap-1">
                    <div className="w-2 h-2 rounded-full bg-red-500/50" />
                    <div className="w-2 h-2 rounded-full bg-yellow-500/50" />
                    <div className="w-2 h-2 rounded-full bg-green-500/50" />
                  </div>
                  <span className={`text-[9px] font-black uppercase tracking-widest ${theme === 'dark' ? 'text-white/40' : 'text-black/40'}`}>
                    Discord Preview
                  </span>
                </div>
                <button
                  onClick={copyToClipboard}
                  disabled={!output}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${theme === 'dark' ? 'bg-white/5 text-orange-500 hover:bg-white/10' : 'bg-black/5 text-orange-600 hover:bg-black/10'}`}
                >
                  <Copy size={12} />
                  {copyStatus}
                </button>
              </div>

              <div className="h-[400px] p-6 overflow-y-auto custom-scrollbar relative">
                <AnimatePresence mode="wait">
                  {output ? (
                    <motion.div 
                      key="output"
                      initial={{ opacity: 0, x: 10 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -10 }}
                      className={`whitespace-pre-wrap font-sans text-sm leading-relaxed ${theme === 'dark' ? 'text-white/90' : 'text-black/90'}`}
                    >
                      {output}
                    </motion.div>
                  ) : (
                    <motion.div 
                      key="empty"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="h-full flex flex-col items-center justify-center space-y-4 opacity-20"
                    >
                      <Shield size={64} strokeWidth={1} />
                      <p className="text-[10px] uppercase tracking-[0.4em] font-black">Awaiting Deployment</p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* Decorative Scanline */}
              <div className={`absolute inset-0 pointer-events-none ${theme === 'dark' ? 'bg-[linear-gradient(rgba(255,255,255,0.01)_1px,transparent_1px)]' : 'bg-[linear-gradient(rgba(0,0,0,0.01)_1px,transparent_1px)]'} bg-[size:100%_4px]`} />
            </div>

            {/* Protocol Alert */}
            <motion.div 
              whileHover={{ x: 5 }}
              className={`p-5 rounded-2xl border flex gap-4 transition-all ${theme === 'dark' ? 'bg-orange-500/5 border-orange-500/20' : 'bg-orange-50 border-orange-200 shadow-sm'}`}
            >
              <div className={`w-10 h-10 rounded-xl flex-shrink-0 flex items-center justify-center ${theme === 'dark' ? 'bg-orange-500/20 text-orange-500' : 'bg-orange-100 text-orange-600'}`}>
                <Shield size={20} />
              </div>
              <div className="space-y-1">
                <h3 className={`text-[10px] font-black uppercase tracking-widest ${theme === 'dark' ? 'text-orange-500' : 'text-orange-700'}`}>Security Protocol 04-A</h3>
                <p className={`text-[10px] leading-relaxed font-medium ${theme === 'dark' ? 'text-white/50' : 'text-black/50'}`}>
                  All formatted intelligence is logged. Unauthorized leaks to rival dynasties will result in immediate termination of access.
                </p>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </main>

      {/* Footer Bar */}
      <footer className={`fixed bottom-0 left-0 right-0 p-4 border-t backdrop-blur-md z-50 flex justify-between items-center ${theme === 'dark' ? 'bg-black/80 border-white/5 text-white/20' : 'bg-white/80 border-black/5 text-black/20'}`}>
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2">
            <div className="w-1.5 h-1.5 rounded-full bg-green-500" />
            <span className="text-[9px] font-black uppercase tracking-[0.2em]">Core Operational</span>
          </div>
          <div className="hidden sm:flex items-center gap-2">
            <span className="text-[9px] font-black uppercase tracking-[0.2em]">Latency: 14ms</span>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <a href="#" className="hover:text-orange-500 transition-colors"><ExternalLink size={12} /></a>
          <span className="text-[9px] font-black uppercase tracking-[0.2em]">Supreme Dynasty © 2026</span>
        </div>
      </footer>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: ${theme === 'dark' ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)'};
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: ${theme === 'dark' ? 'rgba(255, 255, 255, 0.2)' : 'rgba(0, 0, 0, 0.2)'};
        }
        
        @keyframes pulse-subtle {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.7; }
        }
        
        .animate-pulse-subtle {
          animation: pulse-subtle 3s infinite ease-in-out;
        }
      `}</style>
    </div>
  );
}
